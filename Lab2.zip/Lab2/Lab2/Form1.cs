using Lab2_Weather;
using Lab2_WeatherResponse;
using System.Text.Json;

namespace Lab2
{
    public partial class Form1 : Form
    {
        private readonly HttpClient client;
        public Form1()
        {
            InitializeComponent();
            client = new HttpClient();
            InitializeUI();
        }
        private void InitializeUI()
        {
            this.Text = "Weather App";
            this.BackColor = Color.LightBlue;
            textBox1.BackColor = Color.White;
            textBox1.Font = new Font("Arial", 10);
            textBox1.Margin = new Padding(10);
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            textBox1.Size = new Size(ClientSize.Width - 20, ClientSize.Height - 100);
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            if (float.TryParse(textBox2.Text, out float latitude) && float.TryParse(textBox3.Text, out float longitude))
            {
                var call = $"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid=184f86296734df65eb5199f43ab1d193";
                string response = await client.GetStringAsync(call);
                var weatherApiResponse = JsonSerializer.Deserialize<WeatherResponse>(response);

                using (var dbContext = new WeatherBase())
                {
                    var newMain = new WeatherBaseInfo
                    {
                        CityName = weatherApiResponse.name,
                        Country = weatherApiResponse.sys.country,
                        Latitude = weatherApiResponse.coord.lat,
                        Longitude = weatherApiResponse.coord.lon,
                        Timezone = weatherApiResponse.timezone,
                        Temperature = weatherApiResponse.main.temp,
                        Pressure = weatherApiResponse.main.pressure,
                        Humidity = weatherApiResponse.main.humidity,
                        WindSpeed = weatherApiResponse.wind.speed,
                        WindDirection = weatherApiResponse.wind.deg,
                        WeatherCondition = weatherApiResponse.weather[0].main,
                        DateAdded = DateTime.UtcNow
                    };

                    dbContext.WeatherData.Add(newMain);
                    await dbContext.SaveChangesAsync();
                }

                UpdateWeatherInfo(latitude, longitude);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DisplayAllWeatherData();
        }
        private void DisplayAllWeatherData()
        {
            textBox1.Clear();
            using (var dbContext = new WeatherBase())
            {
                var weatherDataList = dbContext.WeatherData.ToList();
                foreach (var weatherData in weatherDataList)
                {
                    textBox1.AppendText($"City: {weatherData.CityName}" + Environment.NewLine);
                    textBox1.AppendText($"Country: {weatherData.Country}" + Environment.NewLine);
                    textBox1.AppendText($"Latitude: {weatherData.Latitude}" + Environment.NewLine);
                    textBox1.AppendText($"Longitude: {weatherData.Longitude}" + Environment.NewLine);
                    textBox1.AppendText($"Timezone: {weatherData.Timezone}" + Environment.NewLine);
                    textBox1.AppendText($"Temperature: {weatherData.Temperature}K" + Environment.NewLine);
                    textBox1.AppendText($"Pressure: {weatherData.Pressure}" + Environment.NewLine);
                    textBox1.AppendText($"Humidity: {weatherData.Humidity}%" + Environment.NewLine);
                    textBox1.AppendText($"Wind Speed: {weatherData.WindSpeed} m/s" + Environment.NewLine);
                    textBox1.AppendText($"Wind Direction: {weatherData.WindDirection}�" + Environment.NewLine);
                    textBox1.AppendText($"Weather Condition: {weatherData.WeatherCondition}" + Environment.NewLine);
                    textBox1.AppendText($"Date Added: {weatherData.DateAdded}" + Environment.NewLine);
                    textBox1.AppendText(Environment.NewLine);
                }
            }
        }
        private void UpdateWeatherInfo(float latitude, float longitude)
        {
            textBox1.Clear();
            using (var dbContext = new WeatherBase())
            {
                var weatherData = dbContext.WeatherData
                   .FirstOrDefault(item => item.Latitude == latitude && item.Longitude == longitude);

                if (weatherData != null)
                {
                    textBox1.AppendText($"City: {weatherData.CityName}" + Environment.NewLine);
                    textBox1.AppendText($"Country: {weatherData.Country}" + Environment.NewLine);
                    textBox1.AppendText($"Latitude: {weatherData.Latitude}" + Environment.NewLine);
                    textBox1.AppendText($"Longitude: {weatherData.Longitude}" + Environment.NewLine);
                    textBox1.AppendText($"Timezone: {weatherData.Timezone}" + Environment.NewLine);
                    textBox1.AppendText($"Temperature: {weatherData.Temperature}K" + Environment.NewLine);
                    textBox1.AppendText($"Pressure: {weatherData.Pressure}" + Environment.NewLine);
                    textBox1.AppendText($"Humidity: {weatherData.Humidity}%" + Environment.NewLine);
                    textBox1.AppendText($"Wind Speed: {weatherData.WindSpeed} m/s" + Environment.NewLine);
                    textBox1.AppendText($"Wind Direction: {weatherData.WindDirection}�" + Environment.NewLine);
                    textBox1.AppendText($"Weather Condition: {weatherData.WeatherCondition}" + Environment.NewLine);
                    textBox1.AppendText($"Date Added: {weatherData.DateAdded}" + Environment.NewLine);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            bool isStartDateValid = DateTime.TryParse(textBox4.Text, out DateTime startDate);
            bool isEndDateValid = DateTime.TryParse(textBox5.Text, out DateTime endDate);
            bool isCityFilterActive = !string.IsNullOrWhiteSpace(textBox6.Text.Trim());
            if ((isStartDateValid && isEndDateValid) || isCityFilterActive)
            {
                if (isStartDateValid && isEndDateValid)
                {
                    if (isCityFilterActive)
                    {
                        string cityFilter = textBox6.Text.Trim();
                        DisplayFilteredWeatherData(startDate, endDate, cityFilter);
                    }
                    else
                    {
                        DisplayFilteredWeatherData(startDate, endDate, null);
                    }
                }
                else if (isCityFilterActive)
                {
                    string cityFilter = textBox6.Text.Trim();
                    DisplayFilteredWeatherData(null, null, cityFilter);
                }
            }
            else
            {
                MessageBox.Show("Please enter at least one filter (start date, end date, or city name).");
            }
        }
        private void DisplayFilteredWeatherData(DateTime? startDate, DateTime? endDate, string cityFilter)
        {
            textBox1.Clear();
            using (var dbContext = new WeatherBase())
            {
                var filteredData = dbContext.WeatherData.AsQueryable();

                if (startDate.HasValue && endDate.HasValue)
                {
                    filteredData = filteredData.Where(item => item.DateAdded.Date >= startDate.Value.Date && item.DateAdded.Date <= endDate.Value.Date);
                }

                if (!string.IsNullOrWhiteSpace(cityFilter))
                {
                    filteredData = filteredData.Where(item => item.CityName.ToLower().Contains(cityFilter.ToLower()));
                }

                var weatherDataList = filteredData.ToList();
                foreach (var weatherData in weatherDataList)
                {
                    textBox1.AppendText($"City: {weatherData.CityName}" + Environment.NewLine);
                    textBox1.AppendText($"Country: {weatherData.Country}" + Environment.NewLine);
                    textBox1.AppendText($"Latitude: {weatherData.Latitude}" + Environment.NewLine);
                    textBox1.AppendText($"Longitude: {weatherData.Longitude}" + Environment.NewLine);
                    textBox1.AppendText($"Timezone: {weatherData.Timezone}" + Environment.NewLine);
                    textBox1.AppendText($"Temperature: {weatherData.Temperature}K" + Environment.NewLine);
                    textBox1.AppendText($"Pressure: {weatherData.Pressure}" + Environment.NewLine);
                    textBox1.AppendText($"Humidity: {weatherData.Humidity}%" + Environment.NewLine);
                    textBox1.AppendText($"Wind Speed: {weatherData.WindSpeed} m/s" + Environment.NewLine);
                    textBox1.AppendText($"Wind Direction: {weatherData.WindDirection}�" + Environment.NewLine);
                    textBox1.AppendText($"Weather Condition: {weatherData.WeatherCondition}" + Environment.NewLine);
                    textBox1.AppendText($"Date Added: {weatherData.DateAdded}" + Environment.NewLine);
                    textBox1.AppendText(Environment.NewLine);
                }
            }
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Lab2_Weather
{
    internal class WeatherBase : DbContext
    {
        public DbSet<WeatherBaseInfo> WeatherData { get; set; }

        public WeatherBase(DbSet<WeatherBaseInfo> weatherData)
        {
            WeatherData = weatherData;
        }

        public WeatherBase()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlite(@"Data Source=WeatherDatabase2.db");
        }
    }
    public class WeatherBaseInfo
    {
        [Key]
        public int Id { get; set; }
        public string? CityName { get; set; }
        public string? Country { get; set; }
        public required float Latitude { get; set; }
        public required float Longitude { get; set; }
        public required int Timezone { get; set; }
        public required float Temperature { get; set; }
        public required int Pressure { get; set; }
        public required int Humidity { get; set; }
        public required float WindSpeed { get; set; }
        public required int WindDirection { get; set; }
        public required string WeatherCondition { get; set; }
        public required DateTime DateAdded { get; set; }
    }

}
